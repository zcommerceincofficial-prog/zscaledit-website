# Handoff: Kairo rebuild (4 pages) from Claude Design, 2026-10-04

Read CLAUDE.md first. Every rule there applies. This file covers only what this export needs.

## What is in this zip

```
site/
  index.dc.html          Home                    -> /
  how-it-works.dc.html   How it works            -> /how-it-works
  open-markets.dc.html   Open markets            -> /open-markets
  book.dc.html           Book the audit          -> /book
  support.js             runtime that renders the .dc.html pages
  tokens.css             ALL colour, type, spacing, motion values (change here, not in pages)
  market-data.js         US outline + the 50 metro placeholders for the map
  kairo-logo-full-transparent.png   logo, unchanged from the owner's file
```

These files are final, approved design. They are not mockups to reinterpret. Copy is verbatim from
the approved copy doc. Do not edit anything inside `site/` by hand (rule 1). Any change after export
goes in `scripts/export-transform.mjs` or another script.

## Steps, in order

1. `git pull`, then `git checkout rebuild-2026-10` (create it from main if missing). Never work on main.
2. Replace the contents of `site/` with the `site/` folder from this zip.
3. Make sure `site-meta.json` has entries for `index`, `how-it-works`, `open-markets`, `book`
   (title, description, canonical). Pages already carry their own title, description, canonical
   and OpenGraph tags. If the transform's shared head duplicates them, keep the page's own values.
4. Run `node scripts/export-transform.mjs`. Expect exit 0 and the "runtime variant (.dc.html pages)"
   line. Read every warning.
5. **Content before JavaScript (technical requirement, not met yet).** The `.dc.html` runtime draws
   the pages in the browser, so `dist/*.html` are close to empty before JS runs. Add a prerender step
   to the transform (for example a headless Chromium pass that loads each built page, waits for
   `#market-map` / `main` to fill, and writes the rendered HTML back, keeping `support.js` so the
   map, the step tick-on and the button press still work). Confirm with `curl` that the copy is
   in the raw HTML.
6. **Booking widget.** In `book`, `<div id="booking-widget"></div>` is empty on purpose. Have the
   transform inject the existing GHL calendar embed (`cPecftm7zMOwaY1YJ7Pg`) into it. The page
   shows "You're booked. See you on the call." when the URL has `?booked=1` or when the embed posts
   a message matching `appointment|booking ... booked|confirmed|created|success`. Set the GHL
   calendar's redirect-after-booking to `/book?booked=1` so this works for sure, then make one real
   test booking (rule 8) with an obviously fake contact name, and delete it afterwards.
7. **Map data.** `market-data.js` -> `KAIRO_MAP.METROS` holds 50 placeholders as
   `["City, ST", lat, lon]`. Replace them with the US Census Bureau list of the 50 largest metro
   areas (same shape). Dots are positioned from lat/lon, so nothing else changes. Each dot is a
   `<button data-metro="City, ST">` inside `#market-map`. No dot is ever marked taken.
8. Keep `/watch` and `/message` via `scripts/keep-list.txt`. They stay noindexed and out of the sitemap.
9. Run `node scripts/mobile-qa.mjs` and read the screenshots (rule 11): zero horizontal overflow,
   44px tap targets, 16px body text.
10. Deploy to preview only:
    `npx wrangler pages deploy dist --project-name=zscaledit-website --branch=rebuild-2026-10`
    Probe the per-deployment URL (rule 6). Leave the noindex header and the disallow-all robots in place.
11. Production moves only after Izaiah says go, through `checklists/launch-gate.md` (rule 5).
12. Add one line to `site-log.md`: date, "rebuild export from Claude Design, 4 pages", deploy hash.

## Open items (do not fill these in yourself)

- `[CONFIRM: photo of Izaiah, where and when it was taken]` shows on Home inside the empty 4:5
  frame. It stays until Izaiah supplies the photo. Never use a stock or generated person.
- The footer says `(c) 2026 Kairo` exactly as in the copy doc. Change it to the copyright symbol only if Izaiah asks.
- `/privacy` and `/terms` are linked in the footer and must exist in `dist/` (existing pages,
  with the domain, email and tool list updated per the copy doc).
- There is no copy for a calendar loading error, so the page shows nothing if the embed fails.
- Step 6 of the design session (two rounds of 30 percent cuts) was not run before export.

## Design system, for reference

- Colours (tokens.css): canvas #0A0F0C, surface #122D20, ink #F2F5F0, muted #A3B0A8,
  hairline #26332B, accent #34C77B, text on accent #0A0F0C. Nothing else.
- Type: DM Serif Display (headings, upright, weight 400) + Fira Sans (everything else), Google Fonts.
  Scale ratio 1.25, phone base 16px, desktop base 18px. Tabular figures on step numbers, day 8, $500.
- Motion: one easing `cubic-bezier(0.16,1,0.3,1)`. 120 / 220 / 360 / 600 ms. Three moments only:
  the map sweep with its plotter head, the How it works steps ticking on, and the primary button press.
  All of it turns off under prefers-reduced-motion (tokens.css).
- Backdrops: the Kairo loop tile on the page background (tokens.css, `body::before`). Inside the
  green panels the backdrops rotate between a cropped loop, the route with arrow, and the loop tile,
  as inline SVG, hairline colour only.
- Icons: one Iconoir arrow (1.5px stroke), inline SVG.
